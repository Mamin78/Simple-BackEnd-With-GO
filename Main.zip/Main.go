package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"sort"
)

var taskDoneMSG = "Task done successfully!"
var historySent = "History sent successfully!"

type Request struct {
	Task    string `json:"task"`
	Numbers []int  `json:"numbers"`
}

type MeanResponse struct {
	Task    string  `json:"task"`
	Numbers []int   `json:"numbers"`
	Answer  float64 `json:"answer"`
	Code    int     `json:"code"`
	Message string  `json:"message"`
}

func NewMeanResponse(task, message string, numbers []int, answer float64, code int) *MeanResponse {
	mr := new(MeanResponse)
	mr.Task = task
	mr.Numbers = numbers
	mr.Answer = answer
	mr.Code = code
	mr.Message = message
	return mr
}

type SortResponse struct {
	Task    string `json:"task"`
	Numbers []int  `json:"numbers"`
	Answer  []int  `json:"answer"`
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func NewSortResponse(task, message string, numbers, answer []int, code int) *SortResponse {
	mr := new(SortResponse)
	mr.Task = task
	mr.Numbers = numbers
	mr.Answer = answer
	mr.Code = code
	mr.Message = message
	return mr
}

type Response interface{}

type SavedMeanResponse struct {
	Task    string  `json:"task"`
	Numbers []int   `json:"numbers"`
	Answer  float64 `json:"answer"`
}

func NewSavedMeanResponse(task string, numbers []int, answer float64) *SavedMeanResponse {
	mr := new(SavedMeanResponse)
	mr.Task = task
	mr.Numbers = numbers
	mr.Answer = answer
	return mr
}

type SavedSortResponse struct {
	Task    string `json:"task"`
	Numbers []int  `json:"numbers"`
	Answer  []int  `json:"answer"`
}

func NewSavedSortResponse(task string, numbers, answer []int) *SavedSortResponse {
	mr := new(SavedSortResponse)
	mr.Task = task
	mr.Numbers = numbers
	mr.Answer = answer
	return mr
}

type Server struct {
	Size    int        `json:"size"`
	History []Response `json:"history"`
	Code    int        `json:"code"`
	Message string     `json:"message"`
}

var serverHistory Server

func getRequestBody(req *http.Request) string {
	reqBody, err := ioutil.ReadAll(req.Body)
	defer req.Body.Close()
	if err != nil {
		println(err)
	}
	return string(reqBody)
}
func unmarshalRequest(reqBody string) *Request {
	var request *Request
	err := json.Unmarshal([]byte(reqBody), &request)
	if err != nil {
		panic("Unmarshall error")
	}
	return request
}

func CalcMean(numbers []int) float64 {
	sum := 0
	for i := 0; i < len(numbers); i++ {
		sum += numbers[i]
	}
	mean := float64(sum) / float64(len(numbers))
	return mean
}

func calculator(w http.ResponseWriter, req *http.Request) {
	if req.Method != "POST" {
		fmt.Fprintf(w, "400 error\n")
		return
	}
	reqBody := getRequestBody(req)
	request := unmarshalRequest(reqBody)

	var savedResponse Response
	var b []byte
	if request.Task == "mean" {
		mean := CalcMean(request.Numbers)
		resp := NewMeanResponse(request.Task, taskDoneMSG, request.Numbers, mean, 200)
		savedResponse = NewSavedMeanResponse(request.Task, request.Numbers, mean)
		serverHistory.History = append(serverHistory.History, savedResponse)
		b, _ = json.Marshal(resp)
	} else {
		answer := make([]int, len(request.Numbers))
		copy(answer, request.Numbers)
		sort.Ints(answer)
		resp := NewSortResponse(request.Task, taskDoneMSG, request.Numbers, answer, 200)
		savedResponse = NewSavedSortResponse(request.Task, request.Numbers, answer)
		serverHistory.History = append(serverHistory.History, savedResponse)
		b, _ = json.Marshal(resp)
	}
	fmt.Fprintln(w, string(b))

	serverHistory.Size = len(serverHistory.History)
}

func history(w http.ResponseWriter, req *http.Request) {
	if req.Method != "GET" {
		fmt.Fprintf(w, "400 error\n")
		return
	}
	b, _ := json.Marshal(serverHistory)
	fmt.Fprintln(w, string(b))
}

func main() {
	serverHistory.Code = 200
	serverHistory.Message = historySent
	http.HandleFunc("/calculator", calculator)
	http.HandleFunc("/history", history)

	http.ListenAndServe(":8080", nil)
}
